# Форк Views RSS: Yandex Elements для Yandex Turbo для Drupal 8

Оригинальный проект на d.org - https://www.drupal.org/project/views_rss_yandex

Использованы 2 патча:
* https://www.drupal.org/project/views_rss/issues/2026943#comment-11119587 - закоментирован как опция на будущее
* Do not reinstall the module - https://www.drupal.org/project/views_rss_georss/issues/2685151

При использовании скопируйте файл templates/views-view-row-rss.html.twig в каталог вашей темы
